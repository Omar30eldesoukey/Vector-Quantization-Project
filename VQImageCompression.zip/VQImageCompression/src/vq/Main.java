package vq;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        // --- RGB PIPELINE (existing) ---
        File trainDir = new File("D:/Programming/JS_basic projects/VQImageCompression/data/train");
        List<int[]> redVecs = new ArrayList<>(), greenVecs = new ArrayList<>(), blueVecs = new ArrayList<>();

        for (File folder : Objects.requireNonNull(trainDir.listFiles())) {
    File[] imageFiles = folder.listFiles();
    if (imageFiles == null) continue;
    for (File imgFile : imageFiles) {
                if (!imgFile.isFile()) continue;
                BufferedImage img = ImageUtils.loadImage(imgFile.getAbsolutePath());
                if (img == null) continue;
                int[][] R = ImageUtils.getChannel(img, 'R');
                int[][] G = ImageUtils.getChannel(img, 'G');
                int[][] B = ImageUtils.getChannel(img, 'B');
                redVecs.addAll(VQEncoderDecoder.extractVectors(R));
                greenVecs.addAll(VQEncoderDecoder.extractVectors(G));
                blueVecs.addAll(VQEncoderDecoder.extractVectors(B));
            }
        }

        int[][] redCodebook = VectorQuantizer.kMeans(redVecs, 256, 20);
        int[][] greenCodebook = VectorQuantizer.kMeans(greenVecs, 256, 20);
        int[][] blueCodebook = VectorQuantizer.kMeans(blueVecs, 256, 20);

        File testDir = new File("D:/Programming/JS_basic projects/VQImageCompression/data/test");
        for (File folder : Objects.requireNonNull(testDir.listFiles())) {
    File[] imageFiles = folder.listFiles();
    if (imageFiles == null) continue;
    for (File imgFile : imageFiles) {
                if (!imgFile.isFile()) continue;
                BufferedImage img = ImageUtils.loadImage(imgFile.getAbsolutePath());
                if (img == null) continue;
                int[][] R = ImageUtils.getChannel(img, 'R');
                int[][] G = ImageUtils.getChannel(img, 'G');
                int[][] B = ImageUtils.getChannel(img, 'B');

                int[][] rIdx = VQEncoderDecoder.compress(R, redCodebook);
                int[][] gIdx = VQEncoderDecoder.compress(G, greenCodebook);
                int[][] bIdx = VQEncoderDecoder.compress(B, blueCodebook);

                int[][] rDec = VQEncoderDecoder.decompress(rIdx, redCodebook);
                int[][] gDec = VQEncoderDecoder.decompress(gIdx, greenCodebook);
                int[][] bDec = VQEncoderDecoder.decompress(bIdx, blueCodebook);

                BufferedImage out = ImageUtils.combineChannels(rDec, gDec, bDec);
                String outputPath = "output/decompressed/" + folder.getName() + "/" + imgFile.getName();
                ImageUtils.saveImage(out, outputPath);

                double psnrR = ImageUtils.calculatePSNR(R, rDec);
                double psnrG = ImageUtils.calculatePSNR(G, gDec);
                double psnrB = ImageUtils.calculatePSNR(B, bDec);

                int originalSize = R.length * R[0].length * 3; // 3 channels, 1 byte each
                int compressedSize = rIdx.length * rIdx[0].length * 3; // 3 indices per 2x2 block (1 byte each)
                double compressionRatio = (double) originalSize / compressedSize;

                System.out.printf("Image: %s\n", imgFile.getName());
                System.out.printf("PSNR [R, G, B]: [%.2f, %.2f, %.2f] dB\n", psnrR, psnrG, psnrB);
                System.out.printf("Compression Ratio: %.2f\n\n", compressionRatio);
            }
        }
        // --- YUV PIPELINE ---
        List<int[]> yVecs = new ArrayList<>(), uVecs = new ArrayList<>(), vVecs = new ArrayList<>();
        int yuvBlock = 2; // 2x2 for Y, 2x2 for subsampled U/V
        // Training for YUV
        for (File folder : Objects.requireNonNull(trainDir.listFiles())) {
            File[] imageFiles = folder.listFiles();
            if (imageFiles == null) continue;
            for (File imgFile : imageFiles) {
                if (!imgFile.isFile()) continue;
                BufferedImage img = ImageUtils.loadImage(imgFile.getAbsolutePath());
                if (img == null) continue;
                int[][][] yuv = ImageUtils.rgbToYuv(img);
                int[][] Y = yuv[0];
                int[][] U = ImageUtils.downsample(yuv[1]);
                int[][] V = ImageUtils.downsample(yuv[2]);
                yVecs.addAll(VQEncoderDecoder.extractVectors(Y));
                uVecs.addAll(VQEncoderDecoder.extractVectors(U));
                vVecs.addAll(VQEncoderDecoder.extractVectors(V));
            }
        }
        int[][] yCodebook = VectorQuantizer.kMeans(yVecs, 256, 20);
        int[][] uCodebook = VectorQuantizer.kMeans(uVecs, 256, 20);
        int[][] vCodebook = VectorQuantizer.kMeans(vVecs, 256, 20);

        // Testing for YUV
        for (File folder : Objects.requireNonNull(testDir.listFiles())) {
            File[] imageFiles = folder.listFiles();
            if (imageFiles == null) continue;
            for (File imgFile : imageFiles) {
                if (!imgFile.isFile()) continue;
                BufferedImage img = ImageUtils.loadImage(imgFile.getAbsolutePath());
                if (img == null) continue;
                int[][][] yuv = ImageUtils.rgbToYuv(img);
                int[][] Y = yuv[0];
                int[][] U = ImageUtils.downsample(yuv[1]);
                int[][] V = ImageUtils.downsample(yuv[2]);

                int[][] yIdx = VQEncoderDecoder.compress(Y, yCodebook);
                int[][] uIdx = VQEncoderDecoder.compress(U, uCodebook);
                int[][] vIdx = VQEncoderDecoder.compress(V, vCodebook);

                int[][] yDec = VQEncoderDecoder.decompress(yIdx, yCodebook);
                int[][] uDec = VQEncoderDecoder.decompress(uIdx, uCodebook);
                int[][] vDec = VQEncoderDecoder.decompress(vIdx, vCodebook);

                // Upsample U, V to original size
                int[][] uUp = ImageUtils.upsample(uDec, Y.length, Y[0].length);
                int[][] vUp = ImageUtils.upsample(vDec, Y.length, Y[0].length);

                BufferedImage outYUV = ImageUtils.yuvToRgb(yDec, uUp, vUp);
                String outputPathYUV = "output/decompressed_yuv/" + folder.getName() + "/" + imgFile.getName();
                ImageUtils.saveImage(outYUV, outputPathYUV);

                // Calculate PSNR for YUV pipeline (in RGB space)
                int[][] Rorig = ImageUtils.getChannel(img, 'R');
                int[][] Gorig = ImageUtils.getChannel(img, 'G');
                int[][] Borig = ImageUtils.getChannel(img, 'B');
                int[][] Rdec = ImageUtils.getChannel(outYUV, 'R');
                int[][] Gdec = ImageUtils.getChannel(outYUV, 'G');
                int[][] Bdec = ImageUtils.getChannel(outYUV, 'B');
                double psnrRyuv = ImageUtils.calculatePSNR(Rorig, Rdec);
                double psnrGyuv = ImageUtils.calculatePSNR(Gorig, Gdec);
                double psnrByuv = ImageUtils.calculatePSNR(Borig, Bdec);

                // Compression ratio for YUV pipeline
                int origSize = Y.length * Y[0].length * 3;
                int compSize = yIdx.length * yIdx[0].length + uIdx.length * uIdx[0].length + vIdx.length * vIdx[0].length;
                double compRatioYUV = (double) origSize / compSize;

                System.out.printf("[YUV] Image: %s\n", imgFile.getName());
                System.out.printf("[YUV] PSNR [R, G, B]: [%.2f, %.2f, %.2f] dB\n", psnrRyuv, psnrGyuv, psnrByuv);
                System.out.printf("[YUV] Compression Ratio: %.2f\n\n", compRatioYUV);
            }
        }
        System.out.println("\n--- COMPARISON: RGB vs YUV ---");
        System.out.println("Check output/decompressed (RGB) and output/decompressed_yuv (YUV) for visual and quantitative comparison.");
    }
}