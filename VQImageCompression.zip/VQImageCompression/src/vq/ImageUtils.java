package vq;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageUtils {
    // Convert RGB image to YUV channels
    public static int[][][] rgbToYuv(BufferedImage img) {
        int width = img.getWidth();
        int height = img.getHeight();
        int[][] Y = new int[height][width];
        int[][] U = new int[height][width];
        int[][] V = new int[height][width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = img.getRGB(x, y);
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;
                int yv = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                int uv = (int)(-0.14713 * r - 0.28886 * g + 0.436 * b) + 128;
                int vv = (int)(0.615 * r - 0.51499 * g - 0.10001 * b) + 128;
                Y[y][x] = clamp(yv);
                U[y][x] = clamp(uv);
                V[y][x] = clamp(vv);
            }
        }
        return new int[][][] { Y, U, V };
    }

    // Convert YUV channels to RGB image
    public static BufferedImage yuvToRgb(int[][] Y, int[][] U, int[][] V) {
        int height = Y.length;
        int width = Y[0].length;
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int yv = Y[y][x];
                int uv = U[y][x] - 128;
                int vv = V[y][x] - 128;
                int r = clamp((int)(yv + 1.13983 * vv));
                int g = clamp((int)(yv - 0.39465 * uv - 0.58060 * vv));
                int b = clamp((int)(yv + 2.03211 * uv));
                int rgb = (r << 16) | (g << 8) | b;
                img.setRGB(x, y, rgb);
            }
        }
        return img;
    }

    // Clamp value to 0-255
    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    // Downsample channel by 2 (nearest neighbor)
    public static int[][] downsample(int[][] channel) {
        int h = channel.length / 2;
        int w = channel[0].length / 2;
        int[][] out = new int[h][w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                out[y][x] = channel[y * 2][x * 2];
            }
        }
        return out;
    }

    // Upsample channel by 2 (nearest neighbor)
    public static int[][] upsample(int[][] channel, int targetH, int targetW) {
        int h = channel.length;
        int w = channel[0].length;
        int[][] out = new int[targetH][targetW];
        for (int y = 0; y < targetH; y++) {
            for (int x = 0; x < targetW; x++) {
                out[y][x] = channel[y / 2][x / 2];
            }
        }
        return out;
    }
    public static int[][] getChannel(BufferedImage img, char channel) {
        int width = img.getWidth();
        int height = img.getHeight();
        int[][] channelData = new int[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = img.getRGB(x, y);
                int value = switch (channel) {
                    case 'R' -> (rgb >> 16) & 0xFF;
                    case 'G' -> (rgb >> 8) & 0xFF;
                    case 'B' -> rgb & 0xFF;
                    default -> 0;
                };
                channelData[y][x] = value;
            }
        }
        return channelData;
    }

    public static BufferedImage combineChannels(int[][] red, int[][] green, int[][] blue) {
        int height = red.length;
        int width = red[0].length;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = red[y][x], g = green[y][x], b = blue[y][x];
                int rgb = (r << 16) | (g << 8) | b;
                image.setRGB(x, y, rgb);
            }
        }
        return image;
    }

    public static void saveImage(BufferedImage img, String path) throws IOException {
        File file = new File(path);
        file.getParentFile().mkdirs();
        ImageIO.write(img, "png", file);
    }

    public static BufferedImage loadImage(String path) throws IOException {
        return ImageIO.read(new File(path));
    }

    public static double calculateMSE(int[][] original, int[][] reconstructed) {
        double sum = 0;
        int h = original.length, w = original[0].length;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int diff = original[y][x] - reconstructed[y][x];
                sum += diff * diff;
            }
        }
        return sum / (h * w);
    }

    public static double calculatePSNR(int[][] original, int[][] reconstructed) {
        double mse = calculateMSE(original, reconstructed);
        if (mse == 0) return Double.POSITIVE_INFINITY;
        return 10 * Math.log10(255 * 255 / mse);
    }
} 
