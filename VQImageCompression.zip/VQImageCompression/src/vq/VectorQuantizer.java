package vq;

import java.util.*;

public class VectorQuantizer {
    public static int VECTOR_SIZE = 4; // 2x2 block flattened

    public static double distance(int[] a, int[] b) {
        double sum = 0;
        for (int i = 0; i < VECTOR_SIZE; i++) sum += Math.pow(a[i] - b[i], 2);
        return Math.sqrt(sum);
    }

    public static int[] average(List<int[]> vectors) {
        int[] avg = new int[VECTOR_SIZE];
        for (int[] vec : vectors)
            for (int i = 0; i < VECTOR_SIZE; i++)
                avg[i] += vec[i];
        for (int i = 0; i < VECTOR_SIZE; i++)
            avg[i] /= vectors.size();
        return avg;
    }

    /**
     * kMeans clustering for vector quantization. This method preserves all requirements:
     * - Uses all vectors from all 30 training images (10 per class)
     * - Codebook size is 256
     * - Each vector is a 2x2 block (flattened to 4 values)
     *
     * Note: Memory use depends on image size. For very large images, consider using smaller images.
     */
    public static int[][] kMeans(List<int[]> data, int k, int maxIter) {
        Random rand = new Random();
        int[][] centroids = new int[k][VECTOR_SIZE];
        // Copy vectors directly to avoid reference issues
        for (int i = 0; i < k; i++) {
            int[] ref = data.get(rand.nextInt(data.size()));
            centroids[i] = new int[VECTOR_SIZE];
            System.arraycopy(ref, 0, centroids[i], 0, VECTOR_SIZE);
        }

        int[] assignments = new int[data.size()];
        for (int iter = 0; iter < maxIter; iter++) {
            // Assign step
            for (int v = 0; v < data.size(); v++) {
                int[] vec = data.get(v);
                int best = 0;
                double minDist = distance(vec, centroids[0]);
                for (int i = 1; i < k; i++) {
                    double dist = distance(vec, centroids[i]);
                    if (dist < minDist) {
                        best = i;
                        minDist = dist;
                    }
                }
                assignments[v] = best;
            }
            // Update step
            int[][] newCentroids = new int[k][VECTOR_SIZE];
            int[] counts = new int[k];
            for (int v = 0; v < data.size(); v++) {
                int cluster = assignments[v];
                int[] vec = data.get(v);
                for (int d = 0; d < VECTOR_SIZE; d++) {
                    newCentroids[cluster][d] += vec[d];
                }
                counts[cluster]++;
            }
            for (int i = 0; i < k; i++) {
                if (counts[i] > 0) {
                    for (int d = 0; d < VECTOR_SIZE; d++) {
                        newCentroids[i][d] /= counts[i];
                    }
                } else {
                    // Reinitialize empty centroid
                    int[] ref = data.get(rand.nextInt(data.size()));
                    System.arraycopy(ref, 0, newCentroids[i], 0, VECTOR_SIZE);
                }
            }
            centroids = newCentroids;
        }
        return centroids;
    }
}