package vq;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class VQEncoderDecoder {

    public static List<int[]> extractVectors(int[][] channel) {
        int h = channel.length;
        int w = channel[0].length;
        List<int[]> vectors = new ArrayList<>();

        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                int[] vec = new int[4];
                vec[0] = channel[y][x];
                vec[1] = channel[y][x + 1];
                vec[2] = channel[y + 1][x];
                vec[3] = channel[y + 1][x + 1];
                vectors.add(vec);
            }
        }
        return vectors;
    }

    public static int[][] compress(int[][] channel, int[][] codebook) {
        int h = channel.length;
        int w = channel[0].length;
        int[][] indices = new int[h / 2][w / 2];

        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                int[] vec = new int[]{channel[y][x], channel[y][x + 1], channel[y + 1][x], channel[y + 1][x + 1]};
                int best = 0;
                double minDist = VectorQuantizer.distance(vec, codebook[0]);
                for (int i = 1; i < codebook.length; i++) {
                    double dist = VectorQuantizer.distance(vec, codebook[i]);
                    if (dist < minDist) {
                        best = i;
                        minDist = dist;
                    }
                }
                indices[y / 2][x / 2] = best;
            }
        }
        return indices;
    }

    public static int[][] decompress(int[][] indices, int[][] codebook) {
        int h = indices.length;
        int w = indices[0].length;
        int[][] channel = new int[h * 2][w * 2];

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int[] vec = codebook[indices[y][x]];
                channel[y * 2][x * 2] = vec[0];
                channel[y * 2][x * 2 + 1] = vec[1];
                channel[y * 2 + 1][x * 2] = vec[2];
                channel[y * 2 + 1][x * 2 + 1] = vec[3];
            }
        }
        return channel;
    }
} 
