import os
from PIL import Image

# Set your target size here
TARGET_SIZE = (128, 128)

# Folders to process
folders = [
    r'data/train/animals',
    r'data/train/faces',
    r'data/train/nature',
    r'data/test/animals',
    r'data/test/faces',
    r'data/test/nature',
]

for folder in folders:
    folder_path = os.path.join(os.path.dirname(__file__), folder)
    for fname in os.listdir(folder_path):
        if not fname.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue
        fpath = os.path.join(folder_path, fname)
        img = Image.open(fpath)
        img = img.resize(TARGET_SIZE, Image.LANCZOS)
        img.save(fpath)
print('All images resized to', TARGET_SIZE)
